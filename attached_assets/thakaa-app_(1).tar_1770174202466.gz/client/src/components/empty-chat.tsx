import { Bot, MessageSquare, Sparkles, Zap } from "lucide-react";

export function EmptyChat() {
  return (
    <div className="flex flex-col items-center justify-center h-full p-8 text-center">
      <div className="relative mb-6">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
          <Bot className="h-10 w-10 text-white" />
        </div>
        <div className="absolute -top-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
          <Sparkles className="h-3 w-3 text-primary-foreground" />
        </div>
      </div>
      
      <h1 className="text-3xl font-bold mb-3 bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
        مرحباً بك في BASSAM AI
      </h1>
      
      <p className="text-muted-foreground text-lg mb-8 max-w-md">
        مساعدك الذكي الشخصي. اسألني أي سؤال وسأساعدك بأفضل طريقة ممكنة.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl">
        <SuggestionCard
          icon={<MessageSquare className="h-5 w-5" />}
          title="اسأل أي سؤال"
          description="يمكنني الإجابة على أسئلتك في مختلف المجالات"
        />
        <SuggestionCard
          icon={<Zap className="h-5 w-5" />}
          title="حلول سريعة"
          description="أقدم لك حلولاً سريعة ومفيدة لمشاكلك"
        />
      </div>
    </div>
  );
}

function SuggestionCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex items-start gap-4 p-4 rounded-lg bg-card border border-card-border hover-elevate transition-colors cursor-default">
      <div className="p-2 rounded-lg bg-primary/10 text-primary shrink-0">
        {icon}
      </div>
      <div className="text-right">
        <h3 className="font-medium mb-1">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
